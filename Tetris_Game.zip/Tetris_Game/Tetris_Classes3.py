#########################################
# Programmer: Tomer Zibman
# Date: 04/12/2016
# File Name: tetris_classes3.py
# Description: These classes form the third and final class template for our Tetris game.
#########################################
import pygame

BLACK     = (  0,  0,  0)
RED       = (255,  0,  0)
GREEN     = (  0,255,  0)
BLUE      = (  0,  0,255)
ORANGE    = (255,127,  0)
CYAN      = (  0,183,235)
MAGENTA   = (255,  0,255)
YELLOW    = (255,255,  0)
WHITE     = (255,255,255)
COLOURS   = [ BLACK,  RED,  GREEN,  BLUE,  ORANGE,  CYAN,  MAGENTA,  YELLOW,  WHITE ]
CLR_names = ['black','red','green','blue','orange','cyan','magenta','yellow','white']
FIGURES   = [  None , 'Z' ,  'S'  ,  'J' ,  'L'   ,  'I' ,   'T'   ,   'O'  , None  ]
sClr = 0

#---------------------------------------#
# initialization of images for blocks   #
#---------------------------------------#
red1 = pygame.image.load('red1.bmp')
red1 = pygame.transform.scale(red1, (25, 25))

green2 = pygame.image.load('green2.bmp')
green2 = pygame.transform.scale(green2, (25, 25))

blue3 = pygame.image.load('blue3.bmp')
blue3 = pygame.transform.scale(blue3, (25, 25))

orange4 = pygame.image.load('orange4.bmp')
orange4 = pygame.transform.scale(orange4, (25, 25))

cyan5 = pygame.image.load('cyan5.bmp')
cyan5 = pygame.transform.scale(cyan5, (25, 25))

magenta6 = pygame.image.load('magenta6.bmp')
magenta6 = pygame.transform.scale(magenta6, (25, 25))

yellow7 = pygame.image.load('yellow7.bmp')
yellow7 = pygame.transform.scale(yellow7, (25, 25))

class Block(object):
    """ A square - basic building block
        data:               behaviour:
            col - column        move left/right/up/down
            row - row           draw
            clr - colour
    """
    def __init__(self, col = 1, row = 1, clr = 1):
        self.col = col
        self.row = row
        self.clr = clr

    def __str__(self):
        return '('+str(self.col)+','+str(self.row)+') '+CLR_names[self.clr]

    def draw(self, surface, gridsize=20,drawShadow=0):      # Method to draw shadows and blit the shapes
        x = self.col * gridsize
        y = self.row * gridsize
        CLR = COLOURS[self.clr]
        if(drawShadow == 0):                                # If the shadow is not being draw, images are being put instead of drawing the shape
            if self.clr==1:
                surface.blit(red1, (x,y))
            elif self.clr==2:
                surface.blit(green2, (x,y))
            elif self.clr==3:
                surface.blit(blue3, (x,y))
            elif self.clr==4:
                surface.blit(orange4, (x,y))
            elif self.clr==5:
                surface.blit(cyan5, (x,y))
            elif self.clr==6:
                surface.blit(magenta6, (x,y))
            elif self.clr==7:
                surface.blit(yellow7, (x,y))
        else:                                               # If the shadow is being drawn, it will be drawn in the same colour as the shape
            if self.clr == 1:
                sClr = RED
            elif self.clr == 2:
                sClr = GREEN
            elif self.clr == 3:
                sClr = BLUE
            elif self.clr == 4:
                sClr = ORANGE
            elif self.clr == 5:
                sClr = CYAN
            elif self.clr == 6:
                sClr = MAGENTA
            elif self.clr == 7:
                sClr = YELLOW
            pygame.draw.rect(surface, sClr,(x,y,gridsize+1,gridsize+1), 3)

    def move_down(self):
        self.row = self.row + 1

#---------------------------------------#
class Cluster(object):
    """ Collection of blocks
        data:
            col - column where the anchor block is located
            row - row where the anchor block is located
            blocksNo - number of blocks
    """
    def __init__(self, col = 1, row = 1, blocksNo = 1):
        self.col = col
        self.row = row
        self.clr = 0
        self.blocks = [Block()]*blocksNo
        self._colOffsets = [0]*blocksNo
        self._rowOffsets = [0]*blocksNo

    def _update(self):
        for i in range(len(self.blocks)):
            blockCOL = self.col+self._colOffsets[i]
            blockROW = self.row+self._rowOffsets[i]
            blockCLR = self.clr
            self.blocks[i]= Block(blockCOL, blockROW, blockCLR)

    def draw(self, surface, gridsize, drawShadow=0):
        for block in self.blocks:
            block.draw(surface, gridsize,drawShadow)

    def collides(self, other):                          # Method that checks for collisoins
        """ Compare each block from a cluster to all blocks from another cluster.
            Return True only if there is a location conflict.
        """
        for block in self.blocks:
            for obstacle in other.blocks:
                if block.col == obstacle.col and block.row == obstacle.row:
                    return True
        return False

    def append(self, other):                            # Method that adds appends objects
        """ Append all blocks from another cluster to this one.
        """
        for block in other.blocks:
            self.blocks.append(Block(block.col,block.row,block.clr))

#---------------------------------------#
class Obstacles(Cluster):
    """ Collection of tetrominoe blocks on the playing field, left from previous shapes.

    """
    def __init__(self, col = 0, row = 0, blocksNo = 0):
        Cluster.__init__(self, col, row, blocksNo)      # initially the playing field is empty(no shapes are left inside the field)

    def show(self):
        print("\nObstacle: ")
        for block in self.blocks:
            print (block)

    def findFullRows(self, top, bottom, columns):       # Method that finds full rows
        fullRows = []
        rows = []
        for block in self.blocks:
            rows.append(block.row)                      # make a list with only the row numbers of all blocks

        for row in range(top, bottom):                  # starting from the top (row 0), and down to the bottom
            if rows.count(row) == columns:              # if the number of blocks with certain row number
                fullRows.append(row)                    # equals to the number of columns -> the row is full
        return fullRows                                 # return a list with the full rows' numbers


    def removeFullRows(self, fullRows):                 # Method to remove full rows
        for row in fullRows:                            # for each full row, STARTING FROM THE TOP (fullRows are in order)
            for i in reversed(range(len(self.blocks))): # check all obstacle blocks in REVERSE ORDER,
                                                        # so when popping them the index doesn't go out of range !!!
                if self.blocks[i].row == row:
                    self.blocks.pop(i)                  # remove each block that is on this row
                elif self.blocks[i].row < row:
                    self.blocks[i].move_down()          # move down each block that is above this row

#---------------------------------------#
class Shape(Cluster):
    """ A tetrominoe in one of the shapes: Z,S,J,L,I,T,O; consists of 4 x Block() objects
        data:               behaviour:
            col - column        move left/right/up/down
            row - row           draw
            clr - colour        rotate
                * figure/shape is defined by the colour
            rot - rotation
    """
    def __init__(self, col = 1, row = 1, clr = 1):
        Cluster.__init__(self, col, row, 4)
        self.clr = clr
        self._rot = 1
        self._colOffsets = [-1, 0, 0, 1]
        self._rowOffsets = [-1,-1, 0, 0]
        self._rotate() # private

    def __str__(self):
        return FIGURES[self.clr]+' ('+str(self.col)+','+str(self.row)+') '+CLR_names[self.clr]

    def _rotate(self):
        """ offsets are assigned starting from the farthest (most distant) block in reference to the anchor block """
        if self.clr == 1:    #           (default rotation)
                             #   o             o o                o
                             # o x               x o            x o          o x
                             # o                                o              o o
            _colOffsets = [[-1,-1, 0, 0], [-1, 0, 0, 1], [ 1, 1, 0, 0], [ 1, 0, 0,-1]] #
            _rowOffsets = [[ 1, 0, 0,-1], [-1,-1, 0, 0], [-1, 0, 0, 1], [ 1, 1, 0, 0]] #
        elif self.clr == 2:  #
                             # o                 o o           o
                             # o x             o x             x o             x o
                             #   o                               o           o o
            _colOffsets = [[-1,-1, 0, 0], [ 1, 0, 0,-1], [ 1, 1, 0, 0], [-1, 0, 0, 1]] #
            _rowOffsets = [[-1, 0, 0, 1], [-1,-1, 0, 0], [ 1, 0, 0,-1], [ 1, 1, 0, 0]] #
        elif self.clr == 3:  #
                             #   o             o                o o
                             #   x             o x o            x           o x o
                             # o o                              o               o
            _colOffsets = [[-1, 0, 0, 0], [-1,-1, 0, 1], [ 1, 0, 0, 0], [ 1, 1, 0,-1]] #
            _rowOffsets = [[ 1, 1, 0,-1], [-1, 0, 0, 0], [-1,-1, 0, 1], [ 1, 0, 0, 0]] #
        elif self.clr == 4:  #
                             # o o                o             o
                             #   x            o x o             x           o x o
                             #   o                              o o         o
            _colOffsets = [[-1, 0, 0, 0], [-1, 0, 1, 1], [  0, 0, 0, 1], [-1,-1, 0, 1]] #
            _rowOffsets = [[-1,-1, 0, 1], [ 0, 0, 0,-1], [ -1, 0, 1, 1], [ 1, 0, 0, 0]] #
        elif self.clr == 5:  #   o                              o
                             #   o                              x
                             #   x            o x o o           o          o o x o
                             #   o                              o
            _colOffsets = [[ 0, 0, 0, 0], [ 2, 1, 0,-1], [ 0, 0, 0, 0], [-2,-1, 0, 1]] #
            _rowOffsets = [[-2,-1, 0, 1], [ 0, 0, 0, 0], [ 2, 1, 0,-1], [ 0, 0, 0, 0]] #
        elif self.clr == 6:  #
                             #   o              o                o
                             # o x            o x o              x o         o x o
                             #   o                               o             o
            _colOffsets = [[ 0,-1, 0, 0], [-1, 0, 0, 1], [ 0, 1, 0, 0], [ 1, 0, 0,-1]] #
            _rowOffsets = [[ 1, 0, 0,-1], [ 0,-1, 0, 0], [-1, 0, 0, 1], [ 0, 1, 0, 0]] #
        elif self.clr == 7:  #
                             # o o            o o               o o          o o
                             # o x            o x               o x          o x
                             #
            _colOffsets = [[-1,-1, 0, 0], [-1,-1, 0, 0], [-1,-1, 0, 0], [-1,-1, 0, 0]] #@@
            _rowOffsets = [[ 0,-1, 0,-1], [ 0,-1, 0,-1], [ 0,-1, 0,-1], [ 0,-1, 0,-1]] #@@
        self._colOffsets = _colOffsets[self._rot]
        self._rowOffsets = _rowOffsets[self._rot]
        self._update() # private

    def move_left(self):            # Method to move the object left
        self.col = self.col - 1
        self._update() # private

    def move_right(self):           # Method to move the object right
        self.col = self.col + 1
        self._update() # private

    def move_down(self):            # Method to move the object down
        self.row = self.row + 1
        self._update() # private

    def move_up(self):              # Method to move the object up
        self.row = self.row - 1
        self._update() # private

    def rotateClkwise(self):        # Method to rotate the object clockwise
        self._rot=(self._rot+1)%4
        self._rotate()

    def rotateCntclkwise(self):     # Method to rotate the object counter clockwise
        self._rot=(self._rot-1)%4
        self._rotate()

    def getRow(self):               # Method that returns the current row
        return self.row

    def getCol(self):               # Method that returns the current column
        return self.col

    def getClr(self):               # Method that returns the current colour
        return self.clr

    def getPosition(self):          # Method that returns the row and the column of the object
        return self.row, self.col

    def getRot(self):               # Method that returns the current rotation
        return self._rot

    def setRot(self,lrot):          # Method that sets the rotation
        self._rot=lrot
        self._rotate()

#---------------------------------------#
class Floor(Cluster):
    """ Horizontal line of blocks
        data:
            col - column where the anchor block is located
            row - row where the anchor block is located
            blocksNo - number of blocks
    """
    def __init__(self, col = 1, row = 1, blocksNo = 1):
        Cluster.__init__(self, col, row, blocksNo)
        for i in range(blocksNo):
            self._colOffsets[i] = i
        self._update() # private

#---------------------------------------#
class Wall(Cluster):
    """ Vertical line of blocks
        data:
            col - column where the anchor block is located
            row - row where the anchor block is located
            blocksNo - number of blocks
    """
    def __init__(self, col = 1, row = 1, blocksNo = 1):
        Cluster.__init__(self, col, row, blocksNo)
        for i in range(blocksNo):
            self._rowOffsets[i] = i
        self._update() # private Make sure all the methods marked as private have an underscore before its name


