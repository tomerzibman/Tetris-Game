#########################################
# Programmer: Tomer Zibman
# Date: 04/12/2016
# File Name: tetris_game
# Description: This program is the final tetris game
#########################################
from Tetris_Classes3 import *
from random import randint
import pygame
pygame.init()


#---------------------------#
# Initialize game variables #
#---------------------------#
HEIGHT = 600
WIDTH  = 800
GRIDSIZE = HEIGHT//24
screen=pygame.display.set_mode((WIDTH,HEIGHT))
GREY = (128,128,128)
score = 0
lines  = 0
total_lines = 0
level = 1
delay = 4
tetrisCount = 0
gameOver = False
seconds = 0
pauseEnable=False
pauseTime=0
frameCount = 0

pygame.mixer.init()
sound_drop= pygame.mixer.Sound("drop.wav")
sound_line_clear= pygame.mixer.Sound("clear_line.wav")
#---------------------------------------#
COLUMNS = 14                            #
ROWS = 22                               #
LEFT = 9                                #
RIGHT = LEFT + COLUMNS                  #
MIDDLE = LEFT + COLUMNS//2              #
TOP = 1                                 #
FLOOR = TOP + ROWS                      #
#---------------------------------------#
bg = pygame.image.load('galaxy.bmp')
bg = pygame.transform.scale(bg, (COLUMNS*GRIDSIZE,ROWS*GRIDSIZE ))
tetrisI = pygame.image.load('tetris_start.bmp')
tetrisI = pygame.transform.scale(tetrisI, (WIDTH,HEIGHT))
faded_rect = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA, 32)
faded_rect.fill((15, 15, 15, 100))
#---------------------------------------#
# Create text objects                   #
#---------------------------------------#
myFont = pygame.font.SysFont('Arial',32,True)
myFont2 = pygame.font.SysFont('Arial',20,True)
myFont3 = pygame.font.SysFont('Arial',48,True)
scoreText = myFont.render('SCORE: '+str(score),1, GREEN)
timeText = myFont.render('TIME: '+str(seconds),1, RED)
levelText = myFont.render('LEVEL: '+str(level),1, RED)
linesText = myFont.render('LINES: '+str(total_lines),1, RED)
pauseText = myFont2.render('Press \'p\' to pause',1, WHITE)
nextShapeText = myFont.render('NEXT SHAPE',1, WHITE)
gameOverText = myFont.render('GAME OVER',1, RED)
pausedText = myFont3.render('P A U S E D',3, WHITE)
resumeText = myFont.render('Press \'p\' to resume', 1, WHITE)
#---------------------------------------#
#   functions                           #
#---------------------------------------#
def redraw_screen():
    screen.fill(BLACK)
    screen.blit(bg, (GRIDSIZE*9,GRIDSIZE))
    next_shape.draw(screen, GRIDSIZE,0)
    shadow_shape.draw(screen, GRIDSIZE,1)
    shape.draw(screen, GRIDSIZE,0)

    for i in range((LEFT+1)*GRIDSIZE,(LEFT+COLUMNS)*GRIDSIZE,GRIDSIZE):     # Create vertical grid liens
        pygame.draw.line(screen,GREY,(i,TOP*GRIDSIZE),(i,(ROWS+1)*GRIDSIZE),1)

    for i in range((TOP+1)*GRIDSIZE,(TOP+ROWS)*GRIDSIZE,GRIDSIZE):          # Create horizontal grid lines
        pygame.draw.line(screen,GREY,(LEFT*GRIDSIZE,i),((LEFT+COLUMNS)*GRIDSIZE,i),1)

    pygame.draw.rect(screen,WHITE,(LEFT*GRIDSIZE,TOP*GRIDSIZE,GRIDSIZE*COLUMNS+1,GRIDSIZE*ROWS+1), 1)
    pygame.draw.rect(screen, WHITE, ((600, 75), (180, 150)),1)
    obstacles.draw(screen, GRIDSIZE)
    scoreText = myFont.render('SCORE: '+str(score),1, GREEN)                # Render new score value
    levelText = myFont.render('LEVEL: '+str(level),1, RED)                  # Render new level value
    linesText = myFont.render('LINES: '+str(total_lines),1, YELLOW)         # Render new lines value
    timeText = myFont.render('TIME: '+str(seconds),1, RED)                  # Render new time value
    screen.blit(nextShapeText, (GRIDSIZE*24,GRIDSIZE*(TOP)))       
    screen.blit(scoreText, (GRIDSIZE*24,GRIDSIZE*(ROWS-9)))
    screen.blit(levelText, (GRIDSIZE*24,GRIDSIZE*(ROWS-1)))
    screen.blit(timeText, (GRIDSIZE*1,30))
    screen.blit(linesText, (GRIDSIZE*24,GRIDSIZE*(ROWS-5)))
    screen.blit(pauseText, (GRIDSIZE*1,GRIDSIZE*(ROWS-1)))
    if pauseEnable:
        screen.blit(faded_rect, (0,0))
        screen.blit(pausedText, (290,300))
        screen.blit(resumeText, (285, 350))
    pygame.display.update()

#--------------------------------------------------------#
# function to update game score, level and cleard lines  #
#--------------------------------------------------------#
def updateGameParameters(lines,lscore,ltotal_lines,ltetris_count,llevel):
    if(lines > 0):
        sound_line_clear.play()
    if(lines == 4):                                                         # Checks if 4 lines where cleard at a time
        ltotal_lines+=lines                 
        ltetris_count+=1                    
        lscore+=(400+ltetris_count*400)     
    else:                                                                   # If 4 lines was not cleard
        lscore+=lines*100                   
        ltotal_lines+=lines
        ltetris_count=0
    print('score',lscore)
    if (lscore<500):
        llevel = 1
    elif (lscore<1000):
        llevel = 2
    else:
        llevel = 3
    return lscore,llevel,ltotal_lines,ltetris_count                         # Returns values in order to update the score, level and total lines

#----------------------------------------------#
# function to show game start page             #
#----------------------------------------------#
def startPage():
    run_loop=True
    count=0                                                                 # counter created to flash keyText
    # loop to wait for user key input
    while(run_loop):
        # build the page with pictures and text
        screen=pygame.display.set_mode((WIDTH,HEIGHT))
        screen.fill(BLACK)
        screen.blit(tetrisI,(0,0))
        pygame.display.set_caption('TETRIS - By Tomer Zibman')
        gameText = myFont3.render('T E T R I S',1, RED)                     # render new time value
        creatorText = myFont.render('by: Tomer Zibman',1, GREEN)            # render new score value
        keyText = myFont2.render('Press \'space bar\' to start',1, BLUE)    # render new score value
        screen.blit(gameText, (310,100))
        screen.blit(creatorText, (295,250))
        if (count%2 == 0):
            screen.blit(keyText, (320,310))
        pygame.display.update()
        pygame.time.delay(500)
        count+=1
        events = pygame.event.get()
        for event in events:
            if (event.type == pygame.KEYDOWN):
                if event.key == pygame.K_SPACE:
                    run_loop=False

#----------------------------------------------#
# function to handle game over page            #
#----------------------------------------------#
def gameOverPage():
    # build the page with pictures and text
    screen=pygame.display.set_mode((WIDTH,HEIGHT))
    screen.fill(BLACK)
    gameOverText = myFont.render('GAME OVER!',1, RED)                       # render new time value
    scoreText = myFont.render('Your score is: '+str(score),1, GREEN)        # render new score value
    lineText = myFont.render('You cleared: '+str(total_lines)+' lines',1, GREEN) # render new score value
    levelText = myFont.render('You made to level: '+str(level),1, GREEN)    # render new score value
    quitText = myFont.render('Press escape to quit game',1, BLUE)            # render new score value
    screen.blit(gameOverText, (300,200))
    screen.blit(scoreText, (280,300))
    screen.blit(lineText, (280,350))
    screen.blit(levelText, (280,400))
    screen.blit(quitText, (240,500))
    pygame.display.update()
    run_loop=True
    # loop to wait for user key input
    while(run_loop):
        events=pygame.event.get()
        for event in events:
            if (event.type == pygame.KEYDOWN):
                if event.key == pygame.K_ESCAPE:
                    run_loop=False

#---------------------------------------#
#   main program                        #
#---------------------------------------#
#---------------------------------------#
# Objects of the game                   #
#---------------------------------------#
shapeNo = randint(1,7)
shape = Shape(MIDDLE,TOP+1,shapeNo)
next_shape = Shape(RIGHT+3.5, TOP+5, randint(1,7))
shadow_shape=Shape(MIDDLE,FLOOR-1,shapeNo)
floor = Floor(LEFT,FLOOR,COLUMNS)
leftWall = Wall(LEFT-1, TOP, ROWS)
rightWall = Wall(RIGHT, TOP, ROWS)
obstacles = Obstacles(LEFT, FLOOR)

startPage()

inPlay = True

print('Score:', score)
print('Level', level)
start_time=pygame.time.get_ticks()
while inPlay:
    frameCount += 1
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            inPlay = False
        if event.type == pygame.KEYDOWN:            # Checks for keydown events
            if event.key == pygame.K_p:             # Checks if the 'p' key was pressed 
                if(pauseEnable==False):             # Checks if the pauseEnable is false to make it True
                    pauseEnable=True
                else:
                    pauseEnable=False
            if(pauseEnable==False):                 # Checks to see if pasueEnable is False to shapes can move
                if event.key == pygame.K_UP:        # Checks to see if the up key was pressed to rotate shape
                    shape.rotateClkwise()
                    shadow_shape.rotateClkwise()
                    if (shape.collides(leftWall) or shape.collides(rightWall) or shape.collides(floor) or shape.collides(obstacles)):
                        shape.rotateCntclkwise()
                        shadow_shape.rotateCntclkwise()

                if event.key == pygame.K_LEFT:      # Checks to see if the left key was pressed to move the shape left
                    shape.move_left()
                    shadow_shape=Shape(shape.getCol(),shape.getRow()+1,shape.getClr())
                    shadow_shape.setRot(shape.getRot())
                    if shape.collides(leftWall) or shape.collides(obstacles):
                        shape.move_right()
                        shadow_shape.move_right()

                if event.key == pygame.K_RIGHT:     # Checks to see if the right key was pressed to move the shape right
                    shape.move_right()
                    shadow_shape=Shape(shape.getCol(),shape.getRow()+1,shape.getClr())
                    shadow_shape.setRot(shape.getRot())
                    if shape.collides(rightWall) or shape.collides(obstacles):
                        shape.move_left()
                        shadow_shape.move_left()

                if event.key == pygame.K_SPACE:     # Checks to see if the space key was pressed in order to drop the shape
                    sound_drop.play()
                    while ((shape.collides(obstacles) == False) and (shape.collides(floor)==False)):
                        shape.move_down()
                    shape.move_up()
                    obstacles.append(shape)
                    fullRows = obstacles.findFullRows(TOP, FLOOR, COLUMNS)    # finds the full rows and removes their blocks from the obstacles
                    score,level,total_lines,tetrisCount = updateGameParameters(len(fullRows),score,total_lines,tetrisCount,level)
                    obstacles.removeFullRows(fullRows)
                    shape=Shape(MIDDLE,TOP+1,next_shape.getClr())
                    shadow_shape=Shape(MIDDLE,TOP+1,next_shape.getClr())
                    next_shape = Shape(RIGHT+4, TOP+5, randint(1,7))
                    if(shape.collides(obstacles)):
                        if (shape.getRow()==TOP+1):
                            gameOver=True
                if event.key == pygame.K_DOWN:      # Checks to see if the down key was pressed in order to move the shape down faster
                    shape.move_down()
                    if (shape.collides(floor) or shape.collides(obstacles)):
                        shape.move_up()
                        obstacles.append(shape)
                        fullRows = obstacles.findFullRows(TOP, FLOOR, COLUMNS)    # finds the full rows and removes their blocks from the obstacles
                        score,level,total_lines,tetrisCount = updateGameParameters(len(fullRows),score,total_lines,tetrisCount,level)
                        obstacles.removeFullRows(fullRows)
                        shape=Shape(MIDDLE,TOP+1,next_shape.getClr())
                        shadow_shape=Shape(MIDDLE,shape.getRow()+1,next_shape.getClr())
                        next_shape = Shape(RIGHT+4, TOP+5, randint(1,7))
                        if(shape.collides(obstacles)):
                            if (shape.getRow()==TOP+1):
                                gameOver=True


    if(pauseEnable == False):                                               # Checks to see if pauseEnable is False 
        seconds=(pygame.time.get_ticks()-start_time)//1000 - pauseTime      # Time is updated only when pauseEnable is False
        if frameCount % 7 == 0:
            shape.move_down()
        if (shape.collides(floor) or shape.collides(obstacles)):            # Checks if shape collides with floor or if it collides with an obstacle and moves shape up
            shape.move_up()
            obstacles.append(shape)
            fullRows = obstacles.findFullRows(TOP, FLOOR, COLUMNS)          # finds the full rows and removes their blocks from the obstacles
            score,level,total_lines,tetrisCount = updateGameParameters(len(fullRows),score,total_lines,tetrisCount,level)
            obstacles.removeFullRows(fullRows)
            shape=Shape(MIDDLE,TOP+1,next_shape.getClr())
            shadow_shape=Shape(MIDDLE,shape.getRow()+1,next_shape.getClr())
            next_shape = Shape(RIGHT+4, TOP+5, randint(1,7))
            if(shape.collides(obstacles)):
                if (shape.getRow()==TOP+1):
                    gameOver=True


        while(shadow_shape.collides(obstacles)==False and shadow_shape.collides(floor)==False): # Checks when the shadow does not collides with obstacles and floor
            shadow_shape.move_down()                                                            # Moves the shadow down is condition is true
        shadow_shape.move_up()
        if gameOver==True:
            gameOverPage()
            inPlay=False

    else:
        pauseTime=(pygame.time.get_ticks()-start_time)//1000 - seconds
    if(inPlay == True):
        redraw_screen()
        pygame.time.delay(delay//level)

pygame.quit()


